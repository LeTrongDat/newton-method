class Solver:
    def execute(self):
        pass
    def set_strategy(self, strategy):
        pass