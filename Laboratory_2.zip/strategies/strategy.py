import random


# from utils import *
class Strategy:
    def execute(self):
        pass
